#pragma once
#include"../../Header.hpp"

namespace FPS_n2 {
	namespace Sceneclass {
	};
};
